eWarState – Initial backgrounds and accessory pack
4 backgrounds + 4 accessories. 1024 x 1024 pixels.

Backgrounds are opaque RGB PNG files; place behind the commander.
Accessories are individual transparent RGBA PNG layers, positioned on the approved 1024 canvas.
Place accessories after head/uniform/armor. Do not crop or automatically trim transparent canvas.

bg01_olive_common: muted olive fabric
bg02_bunker_common: concrete bunker
bg03_gold_premium: golden laurel/rays
bg04_arctic_premium: blue arctic landscape

acc01_black_glasses: black tactical glasses
acc02_gold_aviators: gold aviator glasses
acc03_headset: communications headset
acc04_scarf: shemagh neck wrap

Checks: all assets were visually composited onto the approved base. This does not establish universal compatibility with all equipment.
Known slot conflicts: sunglasses vs goggles/eye masks; headset vs helmets/ear flaps; scarf vs bulky beards, neck guards and high collars. Only one glasses item at a time. For exact occlusion around helmets, headset may need separate back/front portions.

Built-in image generation used for all art; accessory layer placement normalized after generation. No contact sheet substitutes for asset files.
