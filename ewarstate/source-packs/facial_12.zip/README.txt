eWarState facial accessories - initial 12 assets
3 hair styles, 3 beard styles, 3 moustaches, 3 scars.
Each transparent PNG is 1024 x 1024, aligned to the approved master head.
Place after head, before headwear or mask. All were visually tested on the approved head.
Beard assets include matching moustaches; do not stack them with separate moustache assets without testing.
Hair requires hiding/masking under hats and helmets. Beards can intersect neckwear and masks.
Scars are subtle overlays with warm colors matched to this head; different skin tones require checking.
These are not a claim of compatibility with every item combination.
Generated using built-in image generation; aligned through alpha-bounds registration.
